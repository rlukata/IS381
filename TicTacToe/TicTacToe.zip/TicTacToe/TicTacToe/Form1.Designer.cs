﻿namespace TicTacToe
{
    partial class myForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.flowLayoutPanelBaseLayer = new System.Windows.Forms.FlowLayoutPanel();
            this.button0x0 = new System.Windows.Forms.Button();
            this.button0x1 = new System.Windows.Forms.Button();
            this.button0x2 = new System.Windows.Forms.Button();
            this.button1x0 = new System.Windows.Forms.Button();
            this.button1x1 = new System.Windows.Forms.Button();
            this.button1x2 = new System.Windows.Forms.Button();
            this.button2x0 = new System.Windows.Forms.Button();
            this.button2x1 = new System.Windows.Forms.Button();
            this.button2x2 = new System.Windows.Forms.Button();
            this.buttonReset = new System.Windows.Forms.Button();
            this.labelResult = new System.Windows.Forms.Label();
            this.flowLayoutPanelBaseLayer.SuspendLayout();
            this.SuspendLayout();
            // 
            // flowLayoutPanelBaseLayer
            // 
            this.flowLayoutPanelBaseLayer.Controls.Add(this.button0x0);
            this.flowLayoutPanelBaseLayer.Controls.Add(this.button0x1);
            this.flowLayoutPanelBaseLayer.Controls.Add(this.button0x2);
            this.flowLayoutPanelBaseLayer.Controls.Add(this.button1x0);
            this.flowLayoutPanelBaseLayer.Controls.Add(this.button1x1);
            this.flowLayoutPanelBaseLayer.Controls.Add(this.button1x2);
            this.flowLayoutPanelBaseLayer.Controls.Add(this.button2x0);
            this.flowLayoutPanelBaseLayer.Controls.Add(this.button2x1);
            this.flowLayoutPanelBaseLayer.Controls.Add(this.button2x2);
            this.flowLayoutPanelBaseLayer.Location = new System.Drawing.Point(4, 45);
            this.flowLayoutPanelBaseLayer.MaximumSize = new System.Drawing.Size(450, 450);
            this.flowLayoutPanelBaseLayer.MinimumSize = new System.Drawing.Size(150, 150);
            this.flowLayoutPanelBaseLayer.Name = "flowLayoutPanelBaseLayer";
            this.flowLayoutPanelBaseLayer.Size = new System.Drawing.Size(319, 321);
            this.flowLayoutPanelBaseLayer.TabIndex = 2;
            // 
            // button0x0
            // 
            this.button0x0.AutoSize = true;
            this.button0x0.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.button0x0.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button0x0.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button0x0.Location = new System.Drawing.Point(3, 3);
            this.button0x0.MaximumSize = new System.Drawing.Size(150, 150);
            this.button0x0.MinimumSize = new System.Drawing.Size(100, 100);
            this.button0x0.Name = "button0x0";
            this.button0x0.Size = new System.Drawing.Size(100, 100);
            this.button0x0.TabIndex = 1;
            this.button0x0.UseVisualStyleBackColor = true;
            // 
            // button0x1
            // 
            this.button0x1.AutoSize = true;
            this.button0x1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.button0x1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button0x1.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button0x1.Location = new System.Drawing.Point(109, 3);
            this.button0x1.MaximumSize = new System.Drawing.Size(150, 150);
            this.button0x1.MinimumSize = new System.Drawing.Size(100, 100);
            this.button0x1.Name = "button0x1";
            this.button0x1.Size = new System.Drawing.Size(100, 100);
            this.button0x1.TabIndex = 0;
            this.button0x1.UseVisualStyleBackColor = true;
            // 
            // button0x2
            // 
            this.button0x2.AutoSize = true;
            this.button0x2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.button0x2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button0x2.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button0x2.Location = new System.Drawing.Point(215, 3);
            this.button0x2.MaximumSize = new System.Drawing.Size(150, 150);
            this.button0x2.MinimumSize = new System.Drawing.Size(100, 100);
            this.button0x2.Name = "button0x2";
            this.button0x2.Size = new System.Drawing.Size(100, 100);
            this.button0x2.TabIndex = 2;
            this.button0x2.UseVisualStyleBackColor = true;
            // 
            // button1x0
            // 
            this.button1x0.AutoSize = true;
            this.button1x0.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.button1x0.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button1x0.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1x0.Location = new System.Drawing.Point(3, 109);
            this.button1x0.MaximumSize = new System.Drawing.Size(150, 150);
            this.button1x0.MinimumSize = new System.Drawing.Size(100, 100);
            this.button1x0.Name = "button1x0";
            this.button1x0.Size = new System.Drawing.Size(100, 100);
            this.button1x0.TabIndex = 3;
            this.button1x0.UseVisualStyleBackColor = true;
            // 
            // button1x1
            // 
            this.button1x1.AutoSize = true;
            this.button1x1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.button1x1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button1x1.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1x1.Location = new System.Drawing.Point(109, 109);
            this.button1x1.MaximumSize = new System.Drawing.Size(150, 150);
            this.button1x1.MinimumSize = new System.Drawing.Size(100, 100);
            this.button1x1.Name = "button1x1";
            this.button1x1.Size = new System.Drawing.Size(100, 100);
            this.button1x1.TabIndex = 4;
            this.button1x1.UseVisualStyleBackColor = true;
            // 
            // button1x2
            // 
            this.button1x2.AutoSize = true;
            this.button1x2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.button1x2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button1x2.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1x2.Location = new System.Drawing.Point(215, 109);
            this.button1x2.MaximumSize = new System.Drawing.Size(150, 150);
            this.button1x2.MinimumSize = new System.Drawing.Size(100, 100);
            this.button1x2.Name = "button1x2";
            this.button1x2.Size = new System.Drawing.Size(100, 100);
            this.button1x2.TabIndex = 5;
            this.button1x2.UseVisualStyleBackColor = true;
            // 
            // button2x0
            // 
            this.button2x0.AutoSize = true;
            this.button2x0.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.button2x0.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button2x0.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2x0.Location = new System.Drawing.Point(3, 215);
            this.button2x0.MaximumSize = new System.Drawing.Size(150, 150);
            this.button2x0.MinimumSize = new System.Drawing.Size(100, 100);
            this.button2x0.Name = "button2x0";
            this.button2x0.Size = new System.Drawing.Size(100, 100);
            this.button2x0.TabIndex = 7;
            this.button2x0.UseVisualStyleBackColor = true;
            // 
            // button2x1
            // 
            this.button2x1.AutoSize = true;
            this.button2x1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.button2x1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button2x1.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2x1.Location = new System.Drawing.Point(109, 215);
            this.button2x1.MaximumSize = new System.Drawing.Size(150, 150);
            this.button2x1.MinimumSize = new System.Drawing.Size(100, 100);
            this.button2x1.Name = "button2x1";
            this.button2x1.Size = new System.Drawing.Size(100, 100);
            this.button2x1.TabIndex = 8;
            this.button2x1.UseVisualStyleBackColor = true;
            // 
            // button2x2
            // 
            this.button2x2.AutoSize = true;
            this.button2x2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.button2x2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button2x2.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2x2.Location = new System.Drawing.Point(215, 215);
            this.button2x2.MaximumSize = new System.Drawing.Size(150, 150);
            this.button2x2.MinimumSize = new System.Drawing.Size(100, 100);
            this.button2x2.Name = "button2x2";
            this.button2x2.Size = new System.Drawing.Size(100, 100);
            this.button2x2.TabIndex = 9;
            this.button2x2.UseVisualStyleBackColor = true;
            // 
            // buttonReset
            // 
            this.buttonReset.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonReset.Location = new System.Drawing.Point(4, 372);
            this.buttonReset.Name = "buttonReset";
            this.buttonReset.Size = new System.Drawing.Size(322, 37);
            this.buttonReset.TabIndex = 11;
            this.buttonReset.Text = "RESET";
            this.buttonReset.UseVisualStyleBackColor = true;
            this.buttonReset.Click += new System.EventHandler(this.buttonReset_Click);
            // 
            // labelResult
            // 
            this.labelResult.AutoSize = true;
            this.labelResult.BackColor = System.Drawing.SystemColors.Window;
            this.labelResult.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelResult.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelResult.Location = new System.Drawing.Point(85, 9);
            this.labelResult.MaximumSize = new System.Drawing.Size(100, 100);
            this.labelResult.MinimumSize = new System.Drawing.Size(150, 30);
            this.labelResult.Name = "labelResult";
            this.labelResult.Size = new System.Drawing.Size(150, 30);
            this.labelResult.TabIndex = 12;
            this.labelResult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // myForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(327, 415);
            this.Controls.Add(this.labelResult);
            this.Controls.Add(this.buttonReset);
            this.Controls.Add(this.flowLayoutPanelBaseLayer);
            this.Name = "myForm";
            this.Text = "Tic Tac Toe";
            this.flowLayoutPanelBaseLayer.ResumeLayout(false);
            this.flowLayoutPanelBaseLayer.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanelBaseLayer;
        private System.Windows.Forms.Button button0x0;
        private System.Windows.Forms.Button button0x1; 
        private System.Windows.Forms.Button button0x2;
        private System.Windows.Forms.Button button1x0;
        private System.Windows.Forms.Button button1x1;
        private System.Windows.Forms.Button button1x2;
        private System.Windows.Forms.Button button2x0;
        private System.Windows.Forms.Button button2x1;
        private System.Windows.Forms.Button button2x2;
        private System.Windows.Forms.Button buttonReset;
        private System.Windows.Forms.Label labelResult;
    }
}

